package ir.shamsisms.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.icu.text.SimpleDateFormat
import android.icu.util.Calendar
import android.icu.util.ULocale
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PersistableBundle
import android.provider.Settings
import android.provider.Telephony
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.*
import java.util.Date
import java.util.concurrent.Executors

/** nBody/nAddr/auto are computed once at load time so search and filtering stay fast. */
data class Sms(
    val id: Long, val address: String, val body: String, val date: Long, val type: Int,
    val nBody: String, val nAddr: String, val auto: String
)

// Set to false if you want to be able to take screenshots of the app.
private const val SECURE_WINDOW = true
private const val MAX_ROWS = 1000

// Names that contain a ZWNJ are written with an explicit escape so they cannot get lost when editing.
private const val FILTER_ALL = "همه"
private const val FILTER_IMPORTANT = "مهم\u200cها"
private const val FILTER_ARCHIVE = "بایگانی"
private const val CAT_OTP = "رمز یک\u200cبارمصرف"
private const val DENIED_MESSAGE = "مجوز خواندن پیامک داده نشده است؛ بدون آن فهرست نمایش داده نمی\u200cشود."

/** Unifies Arabic/Persian letter variants and digits, drops ZWNJ/ZWJ/tatweel, lowercases Latin. */
private fun normalizeText(s: String): String {
    val sb = StringBuilder(s.length)
    for (ch in s) {
        when (ch) {
            'ي', 'ى' -> sb.append('ی')
            'ك' -> sb.append('ک')
            '\u200c', '\u200d', '\u0640' -> {}
            in '۰'..'۹' -> sb.append('0' + (ch - '۰'))
            in '٠'..'٩' -> sb.append('0' + (ch - '٠'))
            else -> sb.append(ch.lowercaseChar())
        }
    }
    return sb.toString()
}

private val otpWords = listOf("رمز یکبار", "کد تایید", "کد تأیید", "رمز پویا", "verification").map(::normalizeText)
private val otpRegex = Regex("(?<![a-z0-9])otp(?![a-z0-9])")
private val bankWords = listOf("واریز", "برداشت", "موجودی", "تراکنش", "بانک", "شماره کارت").map(::normalizeText)
private val promoWords = listOf("تخفیف", "حراج", "جشنواره", "لغو11", "لغو 11", "پیشنهاد ویژه").map(::normalizeText)

/** [t] must already be normalized. */
private fun autoCategory(t: String): String = when {
    otpWords.any { it in t } || otpRegex.containsMatchIn(t) -> CAT_OTP
    bankWords.any { it in t } -> "بانکی"
    promoWords.any { it in t } -> "تبلیغاتی"
    else -> "سایر"
}

private val dateFormat = object : ThreadLocal<SimpleDateFormat>() {
    override fun initialValue(): SimpleDateFormat =
        SimpleDateFormat("yyyy/MM/dd  HH:mm", ULocale("fa_IR@calendar=persian"))
}

private fun date(millis: Long): String = dateFormat.get().format(Date(millis))

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("metadata", MODE_PRIVATE) }
    private val worker = Executors.newSingleThreadExecutor()
    private val baseCategories = listOf("شخصی", "کاری", "بانکی", CAT_OTP, "تبلیغاتی", "سایر")
    private val periods = listOf("همهٔ تاریخ\u200cها", "امروز", "۷ روز اخیر", "ماه شمسی جاری")
    private var messages = listOf<Sms>()
    private var shown = listOf<Sms>()
    private var query = ""
    private var filter = FILTER_ALL
    private var periodIndex = 0
    private var loading = false
    private var loadedOnce = false
    private var permissionDenied = false
    @Volatile private var generation = 0
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var status: TextView
    private lateinit var root: LinearLayout
    private lateinit var categorySpinner: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val background = Color.rgb(246, 248, 251)
        if (SECURE_WINDOW) window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        // On Android 15 (targetSdk 35) the bar colors are ignored and the app is edge-to-edge;
        // a light background with dark status/navigation icons keeps both cases readable.
        window.statusBarColor = background
        window.navigationBarColor = background
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(background)
        }
        outer.setOnApplyWindowInsetsListener { v, insets ->
            if (Build.VERSION.SDK_INT >= 30) {
                val i = insets.getInsets(
                    WindowInsets.Type.systemBars() or WindowInsets.Type.ime() or WindowInsets.Type.displayCutout()
                )
                v.setPadding(i.left, i.top, i.right, i.bottom)
                WindowInsets.CONSUMED
            } else {
                @Suppress("DEPRECATION")
                v.setPadding(
                    insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                    insets.systemWindowInsetRight, insets.systemWindowInsetBottom
                )
                @Suppress("DEPRECATION")
                insets.consumeSystemWindowInsets()
            }
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(4))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        outer.addView(root, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(outer)

        val title = TextView(this).apply { text = "پیامک شمسی"; textSize = 24f; setTextColor(Color.rgb(25, 65, 90)) }
        root.addView(title)
        root.addView(TextView(this).apply { text = "نگه\u200cداشتن روی پیام: دسته\u200cبندی، بایگانی و مهم"; textSize = 12f })
        val search = EditText(this).apply { hint = "جست\u200cوجوی متن یا شماره"; isSingleLine = true }
        root.addView(search)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { query = s.toString(); render() }
            override fun afterTextChanged(s: Editable?) {}
        })
        val row = LinearLayout(this)
        categorySpinner = Spinner(this)
        row.addView(categorySpinner, LinearLayout.LayoutParams(0, dp(52), 1f))
        val dateSpinner = Spinner(this)
        row.addView(dateSpinner, LinearLayout.LayoutParams(0, dp(52), 1f))
        root.addView(row)
        categorySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, position: Int, id: Long) {
                filter = p?.getItemAtPosition(position).toString(); render()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        dateSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, periods)
        dateSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, position: Int, id: Long) {
                periodIndex = position; render()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        val actions = LinearLayout(this)
        fun button(label: String, action: () -> Unit) {
            actions.addView(Button(this).apply { text = label; textSize = 12f; setOnClickListener { action() } }, LinearLayout.LayoutParams(0, dp(52), 1f))
        }
        button("تازه\u200cسازی") { requestOrLoad() }
        button("دستهٔ جدید") { newCategory() }
        button("نوشتن") { compose("") }
        button("خروجی") { export() }
        root.addView(actions)
        status = TextView(this).apply { textSize = 12f }
        root.addView(status)
        val list = ListView(this)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf<String>())
        list.adapter = adapter
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        list.setOnItemClickListener { _, _, position, _ -> shown.getOrNull(position)?.let { details(it) } }
        list.setOnItemLongClickListener { _, _, position, _ -> shown.getOrNull(position)?.let { options(it) }; true }
        updateCategories()
        requestOrLoad()
    }

    override fun onResume() {
        super.onResume()
        // Coming back from the system settings screen after granting the permission there.
        if (!loadedOnce && !loading && hasSmsPermission()) { permissionDenied = false; load() }
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun categories(): List<String> = baseCategories + (prefs.getStringSet("customCategories", emptySet()) ?: emptySet()).sorted()
    private fun updateCategories() {
        val all = listOf(FILTER_ALL, FILTER_IMPORTANT, FILTER_ARCHIVE) + categories()
        val old = filter
        categorySpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, all)
        categorySpinner.setSelection(all.indexOf(old).coerceAtLeast(0))
    }
    private fun newCategory() {
        val input = EditText(this).apply { hint = "نام دسته" }
        AlertDialog.Builder(this).setTitle("دستهٔ جدید").setView(input).setNegativeButton("لغو", null)
            .setPositiveButton("افزودن") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty() && name !in categories() && name !in listOf(FILTER_ALL, FILTER_IMPORTANT, FILTER_ARCHIVE)) {
                    val set = (prefs.getStringSet("customCategories", emptySet()) ?: emptySet()).toMutableSet()
                    set.add(name); prefs.edit().putStringSet("customCategories", set).apply(); updateCategories()
                }
            }.show()
    }

    private fun hasSmsPermission() =
        checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED

    private fun requestOrLoad() {
        if (!hasSmsPermission()) requestPermissions(arrayOf(Manifest.permission.READ_SMS), 1) else load()
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != 1) return
        if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            permissionDenied = false; load()
        } else {
            permissionDenied = true
            status.text = DENIED_MESSAGE
            showPermissionHelp()
        }
    }
    private fun showPermissionHelp() {
        AlertDialog.Builder(this).setTitle("مجوز پیامک")
            .setMessage(
                "بدون مجوز خواندن پیامک، فهرست خالی می\u200cماند.\n\n" +
                "اگر پنجرهٔ درخواست مجوز ظاهر نشد یا مجوز مسدود بود (در اندروید ۱۳ به بعد برای برنامه\u200cهای نصب\u200cشده خارج از فروشگاه رایج است):\n" +
                "۱) «باز کردن تنظیمات» را بزنید.\n" +
                "۲) از منوی سه\u200cنقطهٔ بالا گزینهٔ «Allow restricted settings / اجازهٔ تنظیمات محدودشده» را انتخاب کنید.\n" +
                "۳) Permissions ← SMS را روی Allow بگذارید و به برنامه برگردید."
            )
            .setPositiveButton("باز کردن تنظیمات") { _, _ ->
                try {
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null)))
                } catch (e: Exception) {
                    Toast.makeText(this, "صفحهٔ تنظیمات باز نشد", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("بستن", null).show()
    }

    private fun load() {
        if (loading) return
        loading = true
        status.text = "در حال خواندن پیامک\u200cها…"
        worker.execute {
            try {
                val result = mutableListOf<Sms>()
                contentResolver.query(Telephony.Sms.CONTENT_URI,
                    arrayOf("_id", "address", "body", "date", "type"), null, null, "date DESC")?.use { c ->
                    while (c.moveToNext()) {
                        val address = c.getString(1) ?: "نامشخص"
                        val body = c.getString(2) ?: ""
                        val nBody = normalizeText(body)
                        result.add(Sms(c.getLong(0), address, body, c.getLong(3), c.getInt(4),
                            nBody, normalizeText(address), autoCategory(nBody)))
                    }
                }
                runOnUiThread { if (!isDestroyed) { messages = result; loading = false; loadedOnce = true; render() } }
            } catch (e: Exception) {
                runOnUiThread { if (!isDestroyed) { loading = false; status.text = "خواندن پیامک ممکن نشد: ${e.localizedMessage}" } }
            }
        }
    }

    private fun category(s: Sms) = prefs.getString("category_${s.id}", null) ?: s.auto
    private fun archived(s: Sms) = prefs.getBoolean("archive_${s.id}", false)
    private fun important(s: Sms) = prefs.getBoolean("important_${s.id}", false)
    private fun cutoff(): Long {
        val c = Calendar.getInstance(ULocale("fa_IR@calendar=persian"))
        when (periodIndex) {
            0 -> return Long.MIN_VALUE
            2 -> return System.currentTimeMillis() - 7L * 24 * 60 * 60 * 1000
            3 -> c.set(Calendar.DAY_OF_MONTH, 1)
        }
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }
    private fun directionLabel(type: Int) = when (type) {
        1 -> "دریافتی"
        2 -> "ارسالی"
        3 -> "پیش\u200cنویس"
        4, 6 -> "در صف ارسال"
        5 -> "ناموفق"
        else -> "پیام"
    }
    private fun render() {
        if (!::adapter.isInitialized || !::status.isInitialized) return
        val token = ++generation
        val snapshot = messages
        val selectedFilter = filter
        val text = normalizeText(query).trim()
        val minDate = cutoff()
        worker.execute {
            if (token != generation) return@execute
            val result = snapshot.filter { s ->
                val categoryMatches = when (selectedFilter) {
                    FILTER_ALL -> !archived(s)
                    FILTER_IMPORTANT -> important(s) && !archived(s)
                    FILTER_ARCHIVE -> archived(s)
                    else -> !archived(s) && category(s) == selectedFilter
                }
                categoryMatches && s.date >= minDate && (text.isEmpty() || text in s.nBody || text in s.nAddr)
            }
            if (token != generation) return@execute
            val labels = result.take(MAX_ROWS).map { s ->
                "${if (important(s)) "★ " else ""}${s.address}  •  ${category(s)}\n${date(s.date)}  •  ${directionLabel(s.type)}\n${s.body.replace('\n', ' ').take(150)}"
            }
            runOnUiThread {
                if (!isDestroyed && token == generation) {
                    shown = result; adapter.clear(); adapter.addAll(labels)
                    status.text = if (permissionDenied && snapshot.isEmpty()) DENIED_MESSAGE else {
                        val extra = if (result.size > MAX_ROWS) " — فقط $MAX_ROWS مورد اول نمایش داده می\u200cشود؛ جست\u200cوجو را دقیق\u200cتر کنید" else ""
                        "${result.size} پیام از ${snapshot.size} پیام — تاریخ بر اساس منطقهٔ زمانی گوشی$extra"
                    }
                }
            }
        }
    }
    private fun details(s: Sms) {
        AlertDialog.Builder(this).setTitle(s.address)
            .setMessage("${date(s.date)}  •  ${directionLabel(s.type)}\nدسته: ${category(s)}\n\n${s.body}")
            .setPositiveButton("پاسخ") { _, _ -> compose(s.address) }
            .setNeutralButton("مدیریت") { _, _ -> options(s) }
            .setNegativeButton("بستن", null).show()
    }
    private fun options(s: Sms) {
        val labels = arrayOf("تغییر دسته", "دسته\u200cبندی خودکار", if (important(s)) "حذف از مهم\u200cها" else "علامت مهم",
            if (archived(s)) "خروج از بایگانی" else "بایگانی", "کپی متن")
        AlertDialog.Builder(this).setTitle(s.address).setItems(labels) { _, which ->
            when (which) {
                0 -> {
                    val names = categories()
                    AlertDialog.Builder(this).setTitle("انتخاب دسته").setItems(names.toTypedArray()) { _, index ->
                        prefs.edit().putString("category_${s.id}", names[index]).apply(); render()
                    }.show()
                }
                1 -> { prefs.edit().remove("category_${s.id}").apply(); render() }
                2 -> { prefs.edit().putBoolean("important_${s.id}", !important(s)).apply(); render() }
                3 -> { prefs.edit().putBoolean("archive_${s.id}", !archived(s)).apply(); render() }
                4 -> {
                    val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                    val clip = ClipData.newPlainText("SMS", s.body)
                    try {
                        // Asks Android 13+ not to show the copied text in the clipboard preview.
                        clip.description.extras = PersistableBundle().apply { putBoolean("android.content.extra.IS_SENSITIVE", true) }
                    } catch (e: Exception) { /* optional hint only */ }
                    clipboard.setPrimaryClip(clip)
                    Toast.makeText(this, "کپی شد", Toast.LENGTH_SHORT).show()
                }
            }
        }.show()
    }
    private fun compose(address: String) {
        try { startActivity(Intent(Intent.ACTION_SENDTO, Uri.fromParts("smsto", address, null))) }
        catch (e: Exception) { Toast.makeText(this, "برنامهٔ ارسال پیامک پیدا نشد", Toast.LENGTH_LONG).show() }
    }
    private fun export() {
        AlertDialog.Builder(this).setTitle("خروجی پیام\u200cها")
            .setMessage("متن و شمارهٔ تمام پیام\u200cهای فیلترشده (${shown.size} پیام) در CSV ذخیره می\u200cشود. فایل حساس است؛ آن را با افراد ناشناس به اشتراک نگذارید. این خروجی برای بازیابی داخل صندوق پیامک نیست.\n\nمتن\u200cهایی که با = + - @ شروع شوند برای امنیت جدول\u200cنگار با یک ' در ابتدا ذخیره می\u200cشوند.")
            .setPositiveButton("انتخاب محل ذخیره") { _, _ ->
                startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "text/csv"; putExtra(Intent.EXTRA_TITLE, "sms-export.csv")
                }, 2)
            }.setNegativeButton("لغو", null).show()
    }
    @Deprecated("Platform activity result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 2 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val snapshot = shown.toList()
        worker.execute {
            try {
                // Quoting handles commas, quotes and newlines. Cells that a spreadsheet could read
                // as a formula (leading = + - @ tab CR) get a leading apostrophe.
                fun csv(s: String, text: Boolean = false): String {
                    val safe = if (text && s.isNotEmpty() && s[0] in "=+-@\t\r") "'$s" else s
                    return "\"" + safe.replace("\"", "\"\"") + "\""
                }
                val stream = contentResolver.openOutputStream(uri) ?: error("Cannot open file")
                stream.bufferedWriter(Charsets.UTF_8).use { w ->
                    w.write("\uFEFFid,address,body,jalali_date,date_millis,category,important,archived\r\n")
                    snapshot.forEach { s ->
                        val row = listOf(
                            csv(s.id.toString()), csv(s.address, true), csv(s.body, true), csv(date(s.date)),
                            csv(s.date.toString()), csv(category(s), true), csv(important(s).toString()), csv(archived(s).toString())
                        )
                        w.write(row.joinToString(",") + "\r\n")
                    }
                }
                runOnUiThread { if (!isDestroyed) Toast.makeText(this, "خروجی ذخیره شد", Toast.LENGTH_LONG).show() }
            } catch (e: Exception) {
                runOnUiThread { if (!isDestroyed) Toast.makeText(this, "ذخیره ناموفق: ${e.localizedMessage}", Toast.LENGTH_LONG).show() }
            }
        }
    }
    override fun onDestroy() { worker.shutdown(); super.onDestroy() }
}
