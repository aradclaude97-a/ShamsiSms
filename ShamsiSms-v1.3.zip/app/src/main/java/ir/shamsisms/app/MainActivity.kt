package ir.shamsisms.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.role.RoleManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.icu.text.SimpleDateFormat
import android.icu.util.Calendar
import android.icu.util.ULocale
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PersistableBundle
import android.provider.Settings
import android.provider.Telephony
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.*
import java.util.Date
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors

/** nBody/nAddr/key/auto are computed once so search, grouping and filtering stay fast. */
data class Sms(
    val id: Long, val address: String, val body: String, val date: Long, val type: Int, val read: Int, val status: Int,
    val nBody: String, val nAddr: String, val key: String, val auto: String
)

/** One conversation row: the newest matching message of a sender plus counts. */
data class Conv(val latest: Sms, val count: Int, val unread: Int)

// Set to false if you want to be able to take screenshots of the app.
private const val SECURE_WINDOW = true
private const val MAX_ROWS = 1000

private val COLOR_CARD = Color.rgb(28, 28, 30)
private val COLOR_SUB = Color.rgb(160, 160, 166)
private val COLOR_ACCENT = Color.rgb(245, 124, 32)
private val COLOR_IN_BUBBLE = Color.rgb(46, 46, 50)
private val COLOR_OUT_BUBBLE = Color.rgb(36, 92, 168)

// Names that contain a ZWNJ are written with an explicit escape so they cannot get lost when editing.
private const val FILTER_ALL = "همه"
private const val FILTER_IMPORTANT = "مهم\u200cها"
private const val FILTER_ARCHIVE = "بایگانی"
private const val CAT_OTP = "رمز یک\u200cبارمصرف"
private const val DENIED_MESSAGE = "مجوز خواندن پیامک داده نشده است؛ بدون آن فهرست نمایش داده نمی\u200cشود."

/** Unifies Arabic/Persian letter variants and digits, drops ZWNJ/ZWJ/tatweel, lowercases Latin. */
internal fun normalizeText(s: String): String {
    val sb = StringBuilder(s.length)
    for (ch in s) {
        when (ch) {
            'ي', 'ى' -> sb.append('ی')
            'ك' -> sb.append('ک')
            '\u200c', '\u200d', '\u0640' -> {}
            in '۰'..'۹' -> sb.append('0' + (ch - '۰'))
            in '٠'..'٩' -> sb.append('0' + (ch - '٠'))
            else -> sb.append(ch.lowercaseChar())
        }
    }
    return sb.toString()
}

/** Same person written as +98912…, 0912… or 98912… ends up in one conversation. */
internal fun keyOf(address: String): String {
    val n = normalizeText(address)
    val digits = n.filter { it.isDigit() }
    return if (digits.length >= 7 && n.none { it.isLetter() }) digits.takeLast(10) else n.trim()
}

private val otpWords = listOf("رمز یکبار", "کد تایید", "کد تأیید", "رمز پویا", "verification").map(::normalizeText)
private val otpRegex = Regex("(?<![a-z0-9])otp(?![a-z0-9])")
private val bankWords = listOf("واریز", "برداشت", "موجودی", "تراکنش", "بانک", "شماره کارت").map(::normalizeText)
private val promoWords = listOf("تخفیف", "حراج", "جشنواره", "لغو11", "لغو 11", "پیشنهاد ویژه").map(::normalizeText)

/** [t] must already be normalized. */
private fun autoCategory(t: String): String = when {
    otpWords.any { it in t } || otpRegex.containsMatchIn(t) -> CAT_OTP
    bankWords.any { it in t } -> "بانکی"
    promoWords.any { it in t } -> "تبلیغاتی"
    else -> "سایر"
}

private fun makeSms(id: Long, address: String, body: String, date: Long, type: Int, read: Int, status: Int): Sms {
    val nBody = normalizeText(body)
    return Sms(id, address, body, date, type, read, status, nBody, normalizeText(address), keyOf(address), autoCategory(nBody))
}

private fun persianFormat(pattern: String): ThreadLocal<SimpleDateFormat> = object : ThreadLocal<SimpleDateFormat>() {
    override fun initialValue(): SimpleDateFormat = SimpleDateFormat(pattern, ULocale("fa_IR@calendar=persian"))
}

private val fmtFull = persianFormat("yyyy/MM/dd  HH:mm")
private val fmtDay = persianFormat("yyyy/MM/dd")
private val fmtYear = persianFormat("yyyy")
private val fmtShort = persianFormat("d MMMM")
private val fmtTime = persianFormat("HH:mm")

private fun fmt(f: ThreadLocal<SimpleDateFormat>, ms: Long): String = f.get().format(Date(ms))
private fun date(ms: Long): String = fmt(fmtFull, ms)

/** Time for today, "4 آذر" for this year, full date otherwise. */
private fun compactDate(ms: Long): String {
    val now = System.currentTimeMillis()
    return when {
        fmt(fmtDay, ms) == fmt(fmtDay, now) -> fmt(fmtTime, ms)
        fmt(fmtYear, ms) == fmt(fmtYear, now) -> fmt(fmtShort, ms)
        else -> fmt(fmtDay, ms)
    }
}

private fun bubbleTime(ms: Long): String {
    val now = System.currentTimeMillis()
    return if (fmt(fmtDay, ms) == fmt(fmtDay, now)) fmt(fmtTime, ms) else fmt(fmtShort, ms) + "  " + fmt(fmtTime, ms)
}

/** Small line icons drawn with Canvas so the project needs no image resources. */
class IconView(ctx: Context, private val kind: Int) : View(ctx) {
    companion object {
        const val MORE = 0
        const val SEARCH = 1
        const val FILTER = 2
        const val BACK = 3
        const val SEND = 4
        const val COMPOSE = 5
    }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val u = minOf(width, height) / 24f
        val cx = width / 2f
        val cy = height / 2f
        p.color = Color.WHITE
        p.strokeWidth = 2f * u
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.style = Paint.Style.STROKE
        when (kind) {
            MORE -> {
                p.style = Paint.Style.FILL
                for (dy in floatArrayOf(-6f, 0f, 6f)) c.drawCircle(cx, cy + dy * u, 1.9f * u, p)
            }
            SEARCH -> {
                c.drawCircle(cx - 2f * u, cy - 2f * u, 6.5f * u, p)
                c.drawLine(cx + 2.8f * u, cy + 2.8f * u, cx + 8f * u, cy + 8f * u, p)
            }
            FILTER -> {
                c.drawLine(cx - 9f * u, cy - 6f * u, cx + 9f * u, cy - 6f * u, p)
                c.drawLine(cx - 6f * u, cy, cx + 6f * u, cy, p)
                c.drawLine(cx - 3f * u, cy + 6f * u, cx + 3f * u, cy + 6f * u, p)
            }
            BACK -> {
                c.drawLine(cx - 8f * u, cy, cx + 8f * u, cy, p)
                c.drawLine(cx + 8f * u, cy, cx + 2f * u, cy - 6f * u, p)
                c.drawLine(cx + 8f * u, cy, cx + 2f * u, cy + 6f * u, p)
            }
            SEND -> {
                p.style = Paint.Style.FILL
                val path = Path()
                path.moveTo(cx - 9f * u, cy)
                path.lineTo(cx + 8f * u, cy - 8f * u)
                path.lineTo(cx + 4f * u, cy)
                path.lineTo(cx + 8f * u, cy + 8f * u)
                path.close()
                c.drawPath(path, p)
            }
            COMPOSE -> {
                c.drawCircle(cx, cy - 1f * u, 8f * u, p)
                c.drawLine(cx - 4f * u, cy + 6.5f * u, cx - 8f * u, cy + 10f * u, p)
                c.drawLine(cx - 3f * u, cy - 1f * u, cx + 3f * u, cy - 1f * u, p)
                c.drawLine(cx, cy - 4f * u, cx, cy + 2f * u, p)
            }
        }
    }
}

/** Round avatar: first letter for named senders, a person glyph for numbers. */
class AvatarView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var letter: String? = null
    private var bg = Color.rgb(58, 58, 62)
    private val palette = intArrayOf(
        Color.rgb(124, 108, 230), Color.rgb(46, 150, 120), Color.rgb(205, 100, 70),
        Color.rgb(60, 130, 200), Color.rgb(190, 80, 140)
    )

    fun bind(address: String) {
        val first = address.trim().firstOrNull()
        if (first != null && first.isLetter()) {
            letter = first.uppercase()
            bg = palette[Math.abs(address.hashCode()) % palette.size]
        } else {
            letter = null
            bg = Color.rgb(58, 58, 62)
        }
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = minOf(w, h) / 2f
        p.style = Paint.Style.FILL
        p.color = bg
        c.drawCircle(w / 2f, h / 2f, r, p)
        val l = letter
        if (l != null) {
            p.color = Color.WHITE
            p.textSize = r * 0.95f
            p.textAlign = Paint.Align.CENTER
            c.drawText(l, w / 2f, h / 2f - (p.descent() + p.ascent()) / 2f, p)
        } else {
            p.color = Color.rgb(178, 178, 184)
            c.drawCircle(w / 2f, h / 2f - r * 0.2f, r * 0.24f, p)
            c.drawArc(RectF(w / 2f - r * 0.48f, h / 2f + r * 0.08f, w / 2f + r * 0.48f, h / 2f + r * 0.98f), 180f, 180f, true, p)
        }
    }
}

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("metadata", MODE_PRIVATE) }
    private val worker = Executors.newSingleThreadExecutor()
    private val baseCategories = listOf("شخصی", "کاری", "بانکی", CAT_OTP, "تبلیغاتی", "سایر")
    private val periods = listOf("همهٔ تاریخ\u200cها", "امروز", "۷ روز اخیر", "ماه شمسی جاری")
    private val sessionSent = CopyOnWriteArrayList<Sms>()
    private var localId = 0L
    private var messages = listOf<Sms>()
    private var shown = listOf<Sms>()
    private var convs = listOf<Conv>()
    private var query = ""
    private var filter = FILTER_ALL
    private var periodIndex = 0
    private var loading = false
    private var loadedOnce = false
    private var lastLoad = 0L
    private var reloadRequested = false
    private var inSettings = false
    private var lastMarkAttempt = 0L
    private var permissionDenied = false
    private var inThread = false
    private var threadKey: String? = null
    private var threadAddress = ""
    private var threadMessages = listOf<Sms>()
    private var pendingSend: Pair<String, String>? = null
    @Volatile private var generation = 0

    private lateinit var listScreen: LinearLayout
    private lateinit var threadScreen: LinearLayout
    private lateinit var convAdapter: ConvAdapter
    private lateinit var msgAdapter: MsgAdapter
    private lateinit var tabsRow: LinearLayout
    private lateinit var searchBox: EditText
    private lateinit var status: TextView
    private lateinit var threadTitle: TextView
    private lateinit var recipientBox: EditText
    private lateinit var msgList: ListView
    private lateinit var input: EditText
    private lateinit var settingsScreen: LinearLayout
    private lateinit var defaultStatus: TextView
    private lateinit var defaultBtn: Button

    companion object {
        /** Set while the activity is visible; receivers call it when the SMS store may have changed. */
        @Volatile var onDataChanged: (() -> Unit)? = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (SECURE_WINDOW) window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
        }
        // On Android 15 the app is edge-to-edge; keep content clear of the system bars and keyboard.
        outer.setOnApplyWindowInsetsListener { v, insets ->
            if (Build.VERSION.SDK_INT >= 30) {
                val i = insets.getInsets(
                    WindowInsets.Type.systemBars() or WindowInsets.Type.ime() or WindowInsets.Type.displayCutout()
                )
                v.setPadding(i.left, i.top, i.right, i.bottom)
                WindowInsets.CONSUMED
            } else {
                @Suppress("DEPRECATION")
                v.setPadding(
                    insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                    insets.systemWindowInsetRight, insets.systemWindowInsetBottom
                )
                @Suppress("DEPRECATION")
                insets.consumeSystemWindowInsets()
            }
        }
        val frame = FrameLayout(this).apply { layoutDirection = View.LAYOUT_DIRECTION_RTL }
        outer.addView(frame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(outer)

        listScreen = buildListScreen()
        threadScreen = buildThreadScreen()
        threadScreen.visibility = View.GONE
        frame.addView(listScreen, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        frame.addView(threadScreen, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        settingsScreen = buildSettingsScreen()
        settingsScreen.visibility = View.GONE
        frame.addView(settingsScreen, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        buildTabs()
        requestOrLoad()
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        onDataChanged = { window.decorView.postDelayed({ if (!isDestroyed && hasSmsPermission()) load() }, 300) }
        if (inSettings) updateSettings()
        if (loading || !hasSmsPermission()) return
        val gap = if (SmsSender.isDefault(this)) 2_000 else 15_000
        if (!loadedOnce) {
            permissionDenied = false; load()
        } else if (System.currentTimeMillis() - lastLoad > gap) {
            load()
        }
    }

    override fun onPause() {
        onDataChanged = null
        super.onPause()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        when {
            inSettings -> closeSettings()
            inThread -> closeThread()
            searchBox.visibility == View.VISIBLE -> toggleSearch()
            else -> super.onBackPressed()
        }
    }

    override fun onDestroy() {
        worker.shutdown()
        super.onDestroy()
    }

    // ---------- UI building ----------

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, r: Float) = GradientDrawable().apply { setColor(color); cornerRadius = r }
    private fun oval(color: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
    private fun icon(kind: Int, onClick: () -> Unit): IconView = IconView(this, kind).apply { setOnClickListener { onClick() } }

    private fun buildListScreen(): LinearLayout {
        val screen = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(32), dp(12), dp(8))
        }
        bar.addView(TextView(this).apply {
            text = "پیام\u200cها"; textSize = 30f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(icon(IconView.FILTER) { pickPeriod() }, LinearLayout.LayoutParams(dp(44), dp(44)))
        bar.addView(icon(IconView.SEARCH) { toggleSearch() }, LinearLayout.LayoutParams(dp(44), dp(44)))
        bar.addView(icon(IconView.MORE) { menu() }, LinearLayout.LayoutParams(dp(44), dp(44)))
        screen.addView(bar)

        searchBox = EditText(this).apply {
            hint = "جست\u200cوجوی متن یا شماره"; isSingleLine = true
            setTextColor(Color.WHITE); setHintTextColor(COLOR_SUB)
            background = rounded(COLOR_CARD, dp(24).toFloat())
            setPadding(dp(16), dp(8), dp(16), dp(8))
            visibility = View.GONE
        }
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { query = s.toString(); render() }
            override fun afterTextChanged(s: Editable?) {}
        })
        screen.addView(searchBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(dp(16), 0, dp(16), dp(8))
        })

        val tabsScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        tabsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(dp(8), 0, dp(8), 0) }
        tabsScroll.addView(tabsRow)
        screen.addView(tabsScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) })

        status = TextView(this).apply { textSize = 11f; setTextColor(COLOR_SUB); setPadding(dp(20), 0, dp(20), dp(6)) }
        screen.addView(status)

        val card = FrameLayout(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            val r = dp(28).toFloat()
            background = GradientDrawable().apply { setColor(COLOR_CARD); cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f) }
            clipToOutline = true
        }
        convAdapter = ConvAdapter()
        val convList = ListView(this).apply {
            adapter = convAdapter; divider = null; dividerHeight = 0
            setPadding(0, dp(8), 0, dp(80)); clipToPadding = false
        }
        convList.setOnItemClickListener { _, _, position, _ ->
            convs.getOrNull(position)?.let { openThread(it.latest.key, it.latest.address) }
        }
        convList.setOnItemLongClickListener { _, _, position, _ -> convs.getOrNull(position)?.let { convActions(it) }; true }
        card.addView(convList, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val fab = FrameLayout(this).apply {
            background = oval(Color.rgb(52, 52, 56)); elevation = dp(6).toFloat(); isClickable = true
            setOnClickListener { openThread(null, "") }
        }
        fab.addView(IconView(this, IconView.COMPOSE), FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER))
        card.addView(fab, FrameLayout.LayoutParams(dp(58), dp(58), Gravity.BOTTOM or Gravity.END).apply {
            marginEnd = dp(24); bottomMargin = dp(24)
        })
        screen.addView(card, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        return screen
    }

    private fun buildThreadScreen(): LinearLayout {
        val screen = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(24), dp(12), dp(8))
        }
        bar.addView(icon(IconView.BACK) { closeThread() }, LinearLayout.LayoutParams(dp(44), dp(44)))
        threadTitle = TextView(this).apply {
            textSize = 20f; setTextColor(Color.WHITE); isSingleLine = true; ellipsize = TextUtils.TruncateAt.END
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START; textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        }
        recipientBox = EditText(this).apply {
            hint = "گیرنده (شماره)"; inputType = InputType.TYPE_CLASS_PHONE; isSingleLine = true
            setTextColor(Color.WHITE); setHintTextColor(COLOR_SUB); visibility = View.GONE
        }
        bar.addView(threadTitle, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(recipientBox, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        screen.addView(bar)

        msgAdapter = MsgAdapter()
        msgList = ListView(this).apply { adapter = msgAdapter; divider = null; dividerHeight = 0; setPadding(0, dp(8), 0, dp(8)); clipToPadding = false }
        msgList.setOnItemLongClickListener { _, _, position, _ -> threadMessages.getOrNull(position)?.let { options(it) }; true }
        screen.addView(msgList, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val inputBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM
            setPadding(dp(8), dp(6), dp(8), dp(8))
        }
        input = EditText(this).apply {
            hint = "پیام"; setHintTextColor(COLOR_SUB); setTextColor(Color.WHITE)
            background = rounded(COLOR_CARD, dp(24).toFloat())
            setPadding(dp(16), dp(10), dp(16), dp(10)); maxLines = 5
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START; textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        }
        val sendBtn = FrameLayout(this).apply {
            background = oval(COLOR_ACCENT); isClickable = true
            setOnClickListener { onSendClicked() }
        }
        sendBtn.addView(IconView(this, IconView.SEND), FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
        inputBar.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        inputBar.addView(sendBtn, LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginStart = dp(8) })
        screen.addView(inputBar)
        return screen
    }

    private fun buildTabs() {
        tabsRow.removeAllViews()
        val names = listOf(FILTER_ALL, FILTER_IMPORTANT) + categories() + FILTER_ARCHIVE
        for (name in names) {
            val selected = name == filter
            val tab = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(12), dp(6), dp(12), 0)
            }
            tab.addView(TextView(this).apply {
                text = if (name == FILTER_ALL) "صندوق دریافت" else name
                textSize = 16f; setTextColor(if (selected) Color.WHITE else COLOR_SUB)
                if (selected) typeface = Typeface.DEFAULT_BOLD
            })
            tab.addView(View(this).apply { setBackgroundColor(if (selected) Color.WHITE else Color.TRANSPARENT) },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(2)).apply { topMargin = dp(6) })
            tab.setOnClickListener { filter = name; buildTabs(); render() }
            tabsRow.addView(tab)
        }
        tabsRow.addView(TextView(this).apply {
            text = "+"; textSize = 24f; setTextColor(COLOR_SUB); setPadding(dp(14), dp(2), dp(14), 0)
            setOnClickListener { newCategory() }
        })
    }

    private inner class ConvRow(ctx: Context) : LinearLayout(ctx) {
        private val avatar = AvatarView(ctx)
        private val name = TextView(ctx)
        private val dateTv = TextView(ctx)
        private val preview = TextView(ctx)
        private val badge = TextView(ctx)

        init {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            name.apply {
                textSize = 17f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
                isSingleLine = true; ellipsize = TextUtils.TruncateAt.END
                textAlignment = View.TEXT_ALIGNMENT_VIEW_START; textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            }
            dateTv.apply { textSize = 12f; setTextColor(COLOR_SUB); textDirection = View.TEXT_DIRECTION_FIRST_STRONG }
            preview.apply {
                textSize = 14f; maxLines = 2; ellipsize = TextUtils.TruncateAt.END
                textAlignment = View.TEXT_ALIGNMENT_VIEW_START; textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            }
            badge.apply {
                textSize = 12f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; minWidth = dp(22)
                setPadding(dp(6), 0, dp(6), 0); background = rounded(COLOR_ACCENT, dp(11).toFloat())
            }
            addView(avatar, LinearLayout.LayoutParams(dp(50), dp(50)))
            val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            val top = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            top.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            top.addView(dateTv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            val bottom = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            bottom.addView(preview, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            bottom.addView(badge, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(22)).apply { marginStart = dp(8) })
            col.addView(top)
            col.addView(bottom)
            addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(14) })
        }

        fun bind(c: Conv) {
            val s = c.latest
            avatar.bind(s.address)
            name.text = s.address
            dateTv.text = compactDate(s.date)
            preview.text = (if (s.type == 1) "" else "شما: ") + s.body.replace('\n', ' ')
            preview.setTextColor(if (c.unread > 0) Color.WHITE else COLOR_SUB)
            if (c.unread > 0) {
                badge.visibility = View.VISIBLE
                badge.text = if (c.unread > 99) "99+" else c.unread.toString()
            } else {
                badge.visibility = View.GONE
            }
        }
    }

    private inner class ConvAdapter : BaseAdapter() {
        override fun getCount() = convs.size
        override fun getItem(position: Int): Any = convs[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row = (convertView as? ConvRow) ?: ConvRow(this@MainActivity)
            row.bind(convs[position])
            return row
        }
    }

    private inner class MsgRow(ctx: Context) : LinearLayout(ctx) {
        private val bubble = TextView(ctx)
        private val time = TextView(ctx)

        init {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(12), dp(4), dp(12), dp(4))
            bubble.apply {
                textSize = 16f; setTextColor(Color.WHITE)
                setPadding(dp(14), dp(9), dp(14), dp(9))
                maxWidth = (resources.displayMetrics.widthPixels * 0.78f).toInt()
                textAlignment = View.TEXT_ALIGNMENT_VIEW_START; textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            }
            time.apply { textSize = 11f; setTextColor(COLOR_SUB); textDirection = View.TEXT_DIRECTION_FIRST_STRONG }
            addView(bubble, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(time, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(2) })
        }

        fun bind(s: Sms) {
            val out = s.type != 1
            bubble.background = rounded(if (out) COLOR_OUT_BUBBLE else COLOR_IN_BUBBLE, dp(18).toFloat())
            bubble.text = s.body
            val state = when {
                s.type == 5 -> "  •  ارسال ناموفق"
                s.type == 4 -> "  •  در حال ارسال"
                s.type == 2 && s.status == 0 -> "  •  تحویل شد"
                s.type == 2 && s.status == 32 -> "  •  در انتظار تحویل"
                s.type == 2 && s.status >= 64 -> "  •  تحویل ناموفق"
                else -> ""
            }
            time.text = bubbleTime(s.date) + state
            val g = if (out) Gravity.END else Gravity.START
            (bubble.layoutParams as LinearLayout.LayoutParams).gravity = g
            (time.layoutParams as LinearLayout.LayoutParams).gravity = g
        }
    }

    private inner class MsgAdapter : BaseAdapter() {
        override fun getCount() = threadMessages.size
        override fun getItem(position: Int): Any = threadMessages[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row = (convertView as? MsgRow) ?: MsgRow(this@MainActivity)
            row.bind(threadMessages[position])
            return row
        }
    }

    // ---------- navigation ----------

    private fun hideKeyboard() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(threadScreen.windowToken, 0)
    }

    private fun toggleSearch() {
        if (searchBox.visibility == View.VISIBLE) {
            searchBox.setText("")
            searchBox.visibility = View.GONE
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(searchBox.windowToken, 0)
        } else {
            searchBox.visibility = View.VISIBLE
            searchBox.requestFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(searchBox, 0)
        }
    }

    private fun openThread(key: String?, address: String) {
        threadKey = key
        threadAddress = address
        inThread = true
        listScreen.visibility = View.GONE
        settingsScreen.visibility = View.GONE
        inSettings = false
        threadScreen.visibility = View.VISIBLE
        input.setText("")
        if (key != null) Notifier.cancel(this, key)
        if (key == null) {
            threadTitle.visibility = View.GONE
            recipientBox.visibility = View.VISIBLE
            recipientBox.setText("")
            recipientBox.requestFocus()
            threadMessages = emptyList()
            msgAdapter.notifyDataSetChanged()
        } else {
            threadTitle.text = address
            threadTitle.visibility = View.VISIBLE
            recipientBox.visibility = View.GONE
            refreshThread()
        }
    }

    private fun closeThread() {
        hideKeyboard()
        inThread = false
        threadScreen.visibility = View.GONE
        listScreen.visibility = View.VISIBLE
        render()
    }

    private fun markSeen(key: String) {
        prefs.edit().putLong("seen_$key", System.currentTimeMillis()).apply()
    }

    private fun refreshThread() {
        val key = threadKey ?: return
        threadMessages = messages.filter { it.key == key }.sortedBy { it.date }
        markSeen(key)
        msgAdapter.notifyDataSetChanged()
        msgList.post { if (msgAdapter.count > 0) msgList.setSelection(msgAdapter.count - 1) }
        markThreadRead(key)
    }

    /** As the default SMS app we may mark messages as read in the system store. */
    private fun markThreadRead(key: String) {
        if (!SmsSender.isDefault(this) || !hasSmsPermission()) return
        val unread = threadMessages.filter { it.type == 1 && it.read == 0 && it.id >= 0 }.map { it.id }
        if (unread.isEmpty() || System.currentTimeMillis() - lastMarkAttempt < 3000) return
        lastMarkAttempt = System.currentTimeMillis()
        worker.execute {
            val v = ContentValues()
            v.put(Telephony.Sms.READ, 1)
            v.put(Telephony.Sms.SEEN, 1)
            for (id in unread) {
                try { contentResolver.update(Uri.withAppendedPath(Telephony.Sms.CONTENT_URI, id.toString()), v, null, null) } catch (e: Exception) { /* ignore */ }
            }
            runOnUiThread { if (!isDestroyed) load() }
        }
    }

    private fun menu() {
        val items = arrayOf("تازه\u200cسازی", "دستهٔ جدید", "خروجی CSV", "تنظیمات")
        AlertDialog.Builder(this).setItems(items) { _, which ->
            when (which) {
                0 -> requestOrLoad()
                1 -> newCategory()
                2 -> export()
                3 -> openSettings()
            }
        }.show()
    }

    private fun pickPeriod() {
        AlertDialog.Builder(this).setTitle("بازهٔ تاریخ")
            .setSingleChoiceItems(periods.toTypedArray(), periodIndex) { d, which ->
                periodIndex = which; d.dismiss(); render()
            }.show()
    }

    private fun convActions(c: Conv) {
        val key = c.latest.key
        val archivedView = filter == FILTER_ARCHIVE
        val labels = arrayOf("علامت\u200cگذاری به\u200cعنوان خوانده\u200cشده", if (archivedView) "خروج از بایگانی" else "بایگانی گفتگو")
        AlertDialog.Builder(this).setTitle(c.latest.address).setItems(labels) { _, which ->
            when (which) {
                0 -> { markSeen(key); render() }
                1 -> {
                    val editor = prefs.edit()
                    messages.filter { it.key == key && it.id >= 0 }.forEach { editor.putBoolean("archive_${it.id}", !archivedView) }
                    editor.apply()
                    render()
                }
            }
        }.show()
    }

    // ---------- settings & default app ----------

    private fun buildSettingsScreen(): LinearLayout {
        val screen = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(24), dp(12), dp(8))
        }
        bar.addView(icon(IconView.BACK) { closeSettings() }, LinearLayout.LayoutParams(dp(44), dp(44)))
        bar.addView(TextView(this).apply {
            text = "تنظیمات"; textSize = 22f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        screen.addView(bar)

        fun label(t: String, size: Float, color: Int) = TextView(this).apply {
            text = t; textSize = size; setTextColor(color)
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START; textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            setPadding(0, dp(4), 0, dp(4))
        }
        fun card(): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(COLOR_CARD, dp(20).toFloat())
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(24)) }
        val gap = { LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(12) } }

        val defaultCard = card()
        defaultCard.addView(label("برنامهٔ پیش\u200cفرض پیامک", 18f, Color.WHITE))
        defaultStatus = label("", 15f, Color.WHITE)
        defaultCard.addView(defaultStatus)
        defaultBtn = Button(this).apply { setOnClickListener { requestDefault() } }
        defaultCard.addView(defaultBtn)
        defaultCard.addView(label(
            "با پیش\u200cفرض بودن، پیام\u200cهای جدید زنده دریافت و در صندوق پیامک ذخیره می\u200cشوند، اعلان می\u200cآید و وضعیت خوانده\u200cشدن و تحویل ثبت می\u200cشود.\n\n" +
            "توجه: MMS و RCS (چت\u200cهای پیشرفتهٔ گوگل/سامسونگ) پشتیبانی نمی\u200cشوند و تا زمانی که این برنامه پیش\u200cفرض است دریافت نخواهند شد. هر زمان می\u200cتوانید برنامهٔ دیگری را پیش\u200cفرض کنید.",
            13f, COLOR_SUB))
        content.addView(defaultCard, gap())

        val deliveryCard = card()
        deliveryCard.addView(Switch(this).apply {
            text = "گزارش تحویل پیامک"; textSize = 16f; setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("delivery_reports", false)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("delivery_reports", checked).apply() }
        })
        deliveryCard.addView(label(
            "پس از ارسال، وضعیت «در انتظار تحویل / تحویل شد / تحویل ناموفق» زیر هر پیام نشان داده می\u200cشود. اگر برنامه پیش\u200cفرض نباشد، فقط یک پیام کوتاه هنگام رسیدن گزارش نشان داده می\u200cشود. بعضی اپراتورها گزارش تحویل را پشتیبانی نمی\u200cکنند یا برای آن هزینه می\u200cگیرند. تنظیم برای پیام\u200cهای بعدی اعمال می\u200cشود.",
            13f, COLOR_SUB))
        content.addView(deliveryCard, gap())

        val notifyCard = card()
        notifyCard.addView(Switch(this).apply {
            text = "اعلان پیام جدید"; textSize = 16f; setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("notifications", true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("notifications", checked).apply()
                if (checked) ensureNotificationPermission()
            }
        })
        notifyCard.addView(label("فقط وقتی برنامه پیش\u200cفرض است و روی صفحه نیست اعلان نشان داده می\u200cشود. متن پیام در صفحهٔ قفل پنهان می\u200cماند.", 13f, COLOR_SUB))
        content.addView(notifyCard, gap())

        screen.addView(ScrollView(this).apply { addView(content) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        return screen
    }

    private fun openSettings() {
        inSettings = true
        listScreen.visibility = View.GONE
        settingsScreen.visibility = View.VISIBLE
        updateSettings()
    }

    private fun closeSettings() {
        inSettings = false
        settingsScreen.visibility = View.GONE
        listScreen.visibility = View.VISIBLE
        render()
    }

    private fun updateSettings() {
        val def = SmsSender.isDefault(this)
        defaultStatus.text = if (def) "✓ این برنامه پیش\u200cفرض پیامک است" else "این برنامه پیش\u200cفرض پیامک نیست"
        defaultBtn.text = if (def) "تغییر برنامهٔ پیش\u200cفرض" else "تنظیم به\u200cعنوان برنامهٔ پیش\u200cفرض"
    }

    private fun requestDefault() {
        try {
            if (SmsSender.isDefault(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
                return
            }
            if (Build.VERSION.SDK_INT >= 29) {
                val rm = getSystemService(RoleManager::class.java)
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_SMS)) {
                    startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_SMS), 5)
                    return
                }
            }
            startActivityForResult(
                Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT).putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName), 5
            )
        } catch (e: Exception) {
            Toast.makeText(this, "تنظیم برنامهٔ پیش\u200cفرض ممکن نشد: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    private fun ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 4)
        }
    }

    /** Opens a conversation from a notification, or a compose request from another app (sms:/smsto: links). */
    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val openKey = i.getStringExtra("open_key")
        if (openKey != null) {
            val addr = i.getStringExtra("open_address") ?: openKey
            i.removeExtra("open_key")
            openThread(openKey, addr)
            return
        }
        if (i.action == Intent.ACTION_SENDTO && i.data != null) {
            val spec = i.data?.schemeSpecificPart ?: ""
            val number = Uri.decode(spec.substringBefore('?').substringBefore(';')).trim()
            val body = i.getStringExtra("sms_body") ?: i.getStringExtra(Intent.EXTRA_TEXT)
                ?: Uri.decode(spec.substringAfter("body=", "").substringBefore('&'))
            i.action = null
            if (number.isNotEmpty()) openThread(keyOf(number), number) else openThread(null, "")
            if (body.isNotEmpty()) input.setText(body)
        }
    }

    // ---------- categories ----------

    private fun categories(): List<String> = baseCategories + (prefs.getStringSet("customCategories", emptySet()) ?: emptySet()).sorted()

    private fun newCategory() {
        val input = EditText(this).apply { hint = "نام دسته" }
        AlertDialog.Builder(this).setTitle("دستهٔ جدید").setView(input).setNegativeButton("لغو", null)
            .setPositiveButton("افزودن") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty() && name !in categories() && name !in listOf(FILTER_ALL, FILTER_IMPORTANT, FILTER_ARCHIVE)) {
                    val set = (prefs.getStringSet("customCategories", emptySet()) ?: emptySet()).toMutableSet()
                    set.add(name); prefs.edit().putStringSet("customCategories", set).apply(); buildTabs()
                }
            }.show()
    }

    // ---------- permissions & loading ----------

    private fun hasSmsPermission() =
        checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED

    private fun requestOrLoad() {
        if (!hasSmsPermission()) requestPermissions(arrayOf(Manifest.permission.READ_SMS), 1) else load()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val granted = grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED
        when (requestCode) {
            1 -> if (granted) {
                permissionDenied = false; load()
            } else {
                permissionDenied = true
                status.text = DENIED_MESSAGE
                showPermissionHelp()
            }
            4 -> if (!granted) Toast.makeText(this, "اعلان\u200cها در تنظیمات اندروید غیرفعال هستند", Toast.LENGTH_LONG).show()
            3 -> if (granted) doSend() else {
                pendingSend = null
                Toast.makeText(this, "بدون مجوز ارسال پیامک نمی\u200cتوان پیام فرستاد", Toast.LENGTH_LONG).show()
                showPermissionHelp()
            }
        }
    }

    private fun showPermissionHelp() {
        AlertDialog.Builder(this).setTitle("مجوز پیامک")
            .setMessage(
                "بدون مجوز پیامک، برنامه کار نمی\u200cکند.\n\n" +
                "اگر پنجرهٔ درخواست مجوز ظاهر نشد یا مجوز مسدود بود (در اندروید ۱۳ به بعد برای برنامه\u200cهای نصب\u200cشده خارج از فروشگاه رایج است):\n" +
                "۱) «باز کردن تنظیمات» را بزنید.\n" +
                "۲) از منوی سه\u200cنقطهٔ بالا گزینهٔ «Allow restricted settings / اجازهٔ تنظیمات محدودشده» را انتخاب کنید.\n" +
                "۳) Permissions ← SMS را روی Allow بگذارید و به برنامه برگردید."
            )
            .setPositiveButton("باز کردن تنظیمات") { _, _ ->
                try {
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null)))
                } catch (e: Exception) {
                    Toast.makeText(this, "صفحهٔ تنظیمات باز نشد", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("بستن", null).show()
    }

    private fun load() {
        if (loading) { reloadRequested = true; return }
        loading = true
        if (!loadedOnce) status.text = "در حال خواندن پیامک\u200cها…"
        worker.execute {
            try {
                val result = mutableListOf<Sms>()
                contentResolver.query(Telephony.Sms.CONTENT_URI,
                    arrayOf("_id", "address", "body", "date", "type", "read", "status"), null, null, "date DESC")?.use { c ->
                    while (c.moveToNext()) {
                        result.add(makeSms(c.getLong(0), c.getString(1) ?: "نامشخص", c.getString(2) ?: "", c.getLong(3), c.getInt(4), c.getInt(5), c.getInt(6)))
                    }
                }
                // Messages sent in this session that Android has not stored in the SMS provider yet stay visible.
                val extra = sessionSent.filter { l ->
                    result.none { it.type != 1 && it.key == l.key && it.body == l.body && Math.abs(it.date - l.date) < 5 * 60 * 1000 }
                }
                val merged = if (extra.isEmpty()) result else (extra + result).sortedByDescending { it.date }
                runOnUiThread {
                    if (!isDestroyed) {
                        messages = merged; loading = false; loadedOnce = true; lastLoad = System.currentTimeMillis()
                        render()
                        if (inThread) refreshThread()
                        if (reloadRequested) { reloadRequested = false; load() }
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { if (!isDestroyed) { loading = false; status.text = "خواندن پیامک ممکن نشد: ${e.localizedMessage}" } }
            }
        }
    }

    // ---------- filtering & rendering ----------

    private fun category(s: Sms) = prefs.getString("category_${s.id}", null) ?: s.auto
    private fun archived(s: Sms) = prefs.getBoolean("archive_${s.id}", false)
    private fun important(s: Sms) = prefs.getBoolean("important_${s.id}", false)

    private fun cutoff(): Long {
        val c = Calendar.getInstance(ULocale("fa_IR@calendar=persian"))
        when (periodIndex) {
            0 -> return Long.MIN_VALUE
            2 -> return System.currentTimeMillis() - 7L * 24 * 60 * 60 * 1000
            3 -> c.set(Calendar.DAY_OF_MONTH, 1)
        }
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    private fun render() {
        if (!::convAdapter.isInitialized || !::status.isInitialized) return
        val token = ++generation
        val snapshot = messages
        val selectedFilter = filter
        val text = normalizeText(query).trim()
        val minDate = cutoff()
        worker.execute {
            if (token != generation) return@execute
            val result = snapshot.filter { s ->
                val categoryMatches = when (selectedFilter) {
                    FILTER_ALL -> !archived(s)
                    FILTER_IMPORTANT -> important(s) && !archived(s)
                    FILTER_ARCHIVE -> archived(s)
                    else -> !archived(s) && category(s) == selectedFilter
                }
                categoryMatches && s.date >= minDate && (text.isEmpty() || text in s.nBody || text in s.nAddr)
            }
            if (token != generation) return@execute
            // result is newest-first, so the first message of each group is the one shown in the list.
            val groups = LinkedHashMap<String, MutableList<Sms>>()
            for (s in result) groups.getOrPut(s.key) { mutableListOf() }.add(s)
            val list = ArrayList<Conv>()
            for ((key, g) in groups) {
                if (list.size >= MAX_ROWS) break
                val seen = prefs.getLong("seen_$key", 0L)
                list.add(Conv(g[0], g.size, g.count { it.type == 1 && it.read == 0 && it.date > seen }))
            }
            runOnUiThread {
                if (!isDestroyed && token == generation) {
                    shown = result; convs = list; convAdapter.notifyDataSetChanged()
                    status.text = if (permissionDenied && snapshot.isEmpty()) DENIED_MESSAGE else {
                        val period = if (periodIndex != 0) " • ${periods[periodIndex]}" else ""
                        val more = if (groups.size > MAX_ROWS) " (فقط $MAX_ROWS مورد اول)" else ""
                        "${groups.size} گفتگو • ${result.size} پیام$period$more"
                    }
                }
            }
        }
    }

    // ---------- message actions ----------

    private fun options(s: Sms) {
        if (s.id < 0) {
            Toast.makeText(this, "این پیام هنوز در صندوق پیامک ذخیره نشده است", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = arrayOf("تغییر دسته", "دسته\u200cبندی خودکار", if (important(s)) "حذف از مهم\u200cها" else "علامت مهم",
            if (archived(s)) "خروج از بایگانی" else "بایگانی", "کپی متن")
        AlertDialog.Builder(this).setTitle(s.address).setItems(labels) { _, which ->
            when (which) {
                0 -> {
                    val names = categories()
                    AlertDialog.Builder(this).setTitle("انتخاب دسته").setItems(names.toTypedArray()) { _, index ->
                        prefs.edit().putString("category_${s.id}", names[index]).apply(); render()
                    }.show()
                }
                1 -> { prefs.edit().remove("category_${s.id}").apply(); render() }
                2 -> { prefs.edit().putBoolean("important_${s.id}", !important(s)).apply(); render() }
                3 -> { prefs.edit().putBoolean("archive_${s.id}", !archived(s)).apply(); render() }
                4 -> {
                    val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                    val clip = ClipData.newPlainText("SMS", s.body)
                    try {
                        // Asks Android 13+ not to show the copied text in the clipboard preview.
                        clip.description.extras = PersistableBundle().apply { putBoolean("android.content.extra.IS_SENSITIVE", true) }
                    } catch (e: Exception) { /* optional hint only */ }
                    clipboard.setPrimaryClip(clip)
                    Toast.makeText(this, "کپی شد", Toast.LENGTH_SHORT).show()
                }
            }
        }.show()
    }

    // ---------- sending ----------

    private fun onSendClicked() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        val dest = if (threadKey == null) recipientBox.text.toString() else threadAddress
        if (dest.any { it.isLetter() }) {
            Toast.makeText(this, "به این فرستنده (نام یا کد خدماتی) نمی\u200cتوان پیام فرستاد", Toast.LENGTH_LONG).show()
            return
        }
        val clean = normalizeText(dest).filter { it.isDigit() || it == '+' }
        if (clean.count { it.isDigit() } < 3) {
            Toast.makeText(this, "شمارهٔ گیرنده معتبر نیست", Toast.LENGTH_LONG).show()
            return
        }
        pendingSend = Pair(clean, text)
        if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.SEND_SMS), 3)
        } else {
            doSend()
        }
    }

    private fun doSend() {
        val (number, text) = pendingSend ?: return
        pendingSend = null
        try {
            SmsSender.send(this, number, text)
            localId -= 1
            val local = makeSms(localId, number, text, System.currentTimeMillis(), 2, 1, -1)
            sessionSent.add(local)
            messages = listOf(local) + messages
            input.setText("")
            if (threadKey == null) {
                threadKey = local.key
                threadAddress = number
                threadTitle.text = number
                threadTitle.visibility = View.VISIBLE
                recipientBox.visibility = View.GONE
            }
            refreshThread()
            render()
        } catch (e: Exception) {
            Toast.makeText(this, "ارسال ناموفق: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- export ----------

    private fun export() {
        AlertDialog.Builder(this).setTitle("خروجی پیام\u200cها")
            .setMessage("متن و شمارهٔ تمام پیام\u200cهای فیلترشده (${shown.size} پیام) در CSV ذخیره می\u200cشود. فایل حساس است؛ آن را با افراد ناشناس به اشتراک نگذارید. این خروجی برای بازیابی داخل صندوق پیامک نیست.\n\nمتن\u200cهایی که با = + - @ شروع شوند برای امنیت جدول\u200cنگار با یک ' در ابتدا ذخیره می\u200cشوند.")
            .setPositiveButton("انتخاب محل ذخیره") { _, _ ->
                startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "text/csv"; putExtra(Intent.EXTRA_TITLE, "sms-export.csv")
                }, 2)
            }.setNegativeButton("لغو", null).show()
    }

    @Deprecated("Platform activity result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 5) {
            updateSettings()
            if (SmsSender.isDefault(this)) {
                Toast.makeText(this, "این برنامه اکنون پیش\u200cفرض پیامک است", Toast.LENGTH_LONG).show()
                ensureNotificationPermission()
                load()
            }
            return
        }
        if (requestCode != 2 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val snapshot = shown.toList()
        worker.execute {
            try {
                // Quoting handles commas, quotes and newlines. Cells that a spreadsheet could read
                // as a formula (leading = + - @ tab CR) get a leading apostrophe.
                fun csv(s: String, text: Boolean = false): String {
                    val safe = if (text && s.isNotEmpty() && s[0] in "=+-@\t\r") "'$s" else s
                    return "\"" + safe.replace("\"", "\"\"") + "\""
                }
                val stream = contentResolver.openOutputStream(uri) ?: error("Cannot open file")
                stream.bufferedWriter(Charsets.UTF_8).use { w ->
                    w.write("\uFEFFid,address,body,jalali_date,date_millis,category,important,archived\r\n")
                    snapshot.forEach { s ->
                        val row = listOf(
                            csv(s.id.toString()), csv(s.address, true), csv(s.body, true), csv(date(s.date)),
                            csv(s.date.toString()), csv(category(s), true), csv(important(s).toString()), csv(archived(s).toString())
                        )
                        w.write(row.joinToString(",") + "\r\n")
                    }
                }
                runOnUiThread { if (!isDestroyed) Toast.makeText(this, "خروجی ذخیره شد", Toast.LENGTH_LONG).show() }
            } catch (e: Exception) {
                runOnUiThread { if (!isDestroyed) Toast.makeText(this, "ذخیره ناموفق: ${e.localizedMessage}", Toast.LENGTH_LONG).show() }
            }
        }
    }
}
