package ir.shamsisms.app

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.Telephony
import android.telephony.SmsManager
import android.telephony.SmsMessage
import android.widget.Toast

/** Sending, including writing to the system SMS store when this app is the default SMS app. */
object SmsSender {
    const val ACTION_SENT = "ir.shamsisms.app.SMS_SENT"
    const val ACTION_DELIVERED = "ir.shamsisms.app.SMS_DELIVERED"

    fun isDefault(ctx: Context): Boolean = Telephony.Sms.getDefaultSmsPackage(ctx) == ctx.packageName

    fun deliveryReportsEnabled(ctx: Context): Boolean =
        ctx.getSharedPreferences("metadata", Context.MODE_PRIVATE).getBoolean("delivery_reports", false)

    @Suppress("DEPRECATION")
    private fun smsManager(ctx: Context): SmsManager =
        if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()

    private fun pending(ctx: Context, action: String, uri: Uri?, mutable: Boolean): PendingIntent {
        val i = Intent(ctx, SendStatusReceiver::class.java).setAction(action)
        if (uri != null) i.data = uri
        // Delivery reports carry the status PDU as an extra that Android fills in, so that one must be mutable.
        val extra = if (!mutable) PendingIntent.FLAG_IMMUTABLE else if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
        return PendingIntent.getBroadcast(ctx, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or extra)
    }

    fun send(ctx: Context, number: String, text: String) {
        val app = ctx.applicationContext
        val sm = smsManager(app)
        val parts = sm.divideMessage(text)
        val reports = deliveryReportsEnabled(app)
        var rowUri: Uri? = null
        if (isDefault(app)) {
            // A default SMS app must write its own sent messages to the system store.
            val v = ContentValues()
            v.put(Telephony.Sms.ADDRESS, number)
            v.put(Telephony.Sms.BODY, text)
            v.put(Telephony.Sms.DATE, System.currentTimeMillis())
            v.put(Telephony.Sms.READ, 1)
            v.put(Telephony.Sms.SEEN, 1)
            v.put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_OUTBOX)
            v.put(Telephony.Sms.STATUS, if (reports) Telephony.Sms.STATUS_PENDING else Telephony.Sms.STATUS_NONE)
            rowUri = try { app.contentResolver.insert(Telephony.Sms.CONTENT_URI, v) } catch (e: Exception) { null }
        }
        try {
            val sentPi = pending(app, ACTION_SENT, rowUri, false)
            val deliveryPi = if (reports) pending(app, ACTION_DELIVERED, rowUri, true) else null
            if (parts.size > 1) {
                val sents = ArrayList<PendingIntent>(parts.map { sentPi })
                val dels = deliveryPi?.let { d -> ArrayList<PendingIntent>(parts.map { d }) }
                sm.sendMultipartTextMessage(number, null, parts, sents, dels)
            } else {
                sm.sendTextMessage(number, null, text, sentPi, deliveryPi)
            }
        } catch (e: Exception) {
            if (rowUri != null) SendStatusReceiver.updateRow(app, rowUri, Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_FAILED)
            throw e
        }
    }
}

/** Receives "sent" and "delivered" results and records them in the system store. */
class SendStatusReceiver : BroadcastReceiver() {
    companion object {
        fun updateRow(ctx: Context, uri: Uri, column: String, value: Int) {
            try {
                val v = ContentValues()
                v.put(column, value)
                ctx.contentResolver.update(uri, v, null, null)
            } catch (e: Exception) { /* not allowed unless default SMS app */ }
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        val uri = intent.data
        val isDefault = SmsSender.isDefault(context)
        when (intent.action) {
            SmsSender.ACTION_SENT -> {
                val ok = resultCode == Activity.RESULT_OK
                if (uri != null && isDefault) {
                    updateRow(context, uri, Telephony.Sms.TYPE,
                        if (ok) Telephony.Sms.MESSAGE_TYPE_SENT else Telephony.Sms.MESSAGE_TYPE_FAILED)
                }
                if (!ok) Toast.makeText(context, "ارسال پیامک ناموفق بود (کد $resultCode)", Toast.LENGTH_LONG).show()
            }
            SmsSender.ACTION_DELIVERED -> {
                val status = deliveryStatus(intent)
                if (uri != null && isDefault) {
                    updateRow(context, uri, Telephony.Sms.STATUS, status)
                } else if (status == Telephony.Sms.STATUS_COMPLETE) {
                    Toast.makeText(context, "پیام تحویل داده شد", Toast.LENGTH_SHORT).show()
                } else if (status == Telephony.Sms.STATUS_FAILED) {
                    Toast.makeText(context, "تحویل پیام ناموفق بود", Toast.LENGTH_LONG).show()
                }
            }
        }
        MainActivity.onDataChanged?.invoke()
    }

    /** TP-Status: below 32 completed, 32..63 still trying, 64 and above permanent failure. */
    private fun deliveryStatus(intent: Intent): Int {
        val pdu = intent.getByteArrayExtra("pdu") ?: return Telephony.Sms.STATUS_COMPLETE
        return try {
            @Suppress("DEPRECATION")
            val st = SmsMessage.createFromPdu(pdu, intent.getStringExtra("format")).status
            when {
                st < 32 -> Telephony.Sms.STATUS_COMPLETE
                st >= 64 -> Telephony.Sms.STATUS_FAILED
                else -> Telephony.Sms.STATUS_PENDING
            }
        } catch (e: Exception) {
            Telephony.Sms.STATUS_COMPLETE
        }
    }
}

/** Incoming SMS: only delivered to the default SMS app, which must store the message itself. */
class SmsDeliverReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_DELIVER_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (msgs == null || msgs.isEmpty()) return
        val address = msgs[0].displayOriginatingAddress ?: msgs[0].originatingAddress ?: "نامشخص"
        val body = msgs.joinToString("") { it.displayMessageBody ?: "" }
        val v = ContentValues()
        v.put(Telephony.Sms.ADDRESS, address)
        v.put(Telephony.Sms.BODY, body)
        v.put(Telephony.Sms.DATE, System.currentTimeMillis())
        v.put(Telephony.Sms.DATE_SENT, msgs[0].timestampMillis)
        v.put(Telephony.Sms.READ, 0)
        v.put(Telephony.Sms.SEEN, 0)
        v.put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_INBOX)
        val sub = intent.getIntExtra("subscription", -1)
        if (sub != -1) v.put(Telephony.Sms.SUBSCRIPTION_ID, sub)
        try { context.contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI, v) } catch (e: Exception) { /* ignore */ }
        // When the app is on screen it refreshes itself; otherwise show a notification.
        if (MainActivity.onDataChanged == null) Notifier.show(context, address, body)
        MainActivity.onDataChanged?.invoke()
    }
}

/** Required for being eligible as default SMS app. MMS is not supported, messages are ignored. */
class MmsWapReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) { /* MMS not supported */ }
}

/** Required for the default SMS app: "reply by message" from the call screen. */
class RespondViaMessageService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val text = intent?.getStringExtra(Intent.EXTRA_TEXT)
        val number = intent?.data?.schemeSpecificPart?.substringBefore('?')?.let { Uri.decode(it) }
        if (!text.isNullOrBlank() && !number.isNullOrBlank()) {
            try { SmsSender.send(this, number, text) } catch (e: Exception) { /* nothing to show here */ }
        }
        stopSelf(startId)
        return START_NOT_STICKY
    }
}

object Notifier {
    private const val CHANNEL = "incoming"

    private fun idFor(key: String) = key.hashCode() and 0x7fffffff

    fun show(ctx: Context, address: String, body: String) {
        val prefs = ctx.getSharedPreferences("metadata", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("notifications", true)) return
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "پیام\u200cهای جدید", NotificationManager.IMPORTANCE_HIGH))
        val key = keyOf(address)
        val open = Intent(ctx, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("open_key", key)
            putExtra("open_address", address)
        }
        val id = idFor(key)
        val pi = PendingIntent.getActivity(ctx, id, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val publicVersion = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle("پیام جدید")
            .build()
        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle(address)
            .setContentText(body)
            .setStyle(Notification.BigTextStyle().bigText(body))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setCategory(Notification.CATEGORY_MESSAGE)
            .setVisibility(Notification.VISIBILITY_PRIVATE)
            .setPublicVersion(publicVersion)
            .build()
        nm.notify(id, n)
    }

    fun cancel(ctx: Context, key: String) {
        ctx.getSystemService(NotificationManager::class.java)?.cancel(idFor(key))
    }
}
